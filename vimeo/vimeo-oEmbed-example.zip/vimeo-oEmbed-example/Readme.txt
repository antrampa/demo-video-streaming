Hi!

These are two examples of how to use oEmbed to quickly get the embed code
for a Vimeo Video.

For the PHP example, all you need to do is move php-example.php to your server.
You can try it out with a different video by appending ?url= and the the
video's url to the page.

In the Javascript example, you can change which video is used by editing
the "clipUrl" variable.

For more documentation on the API go to http://www.vimeo.com/api

- Brad Dougherty (October 1, 2008)