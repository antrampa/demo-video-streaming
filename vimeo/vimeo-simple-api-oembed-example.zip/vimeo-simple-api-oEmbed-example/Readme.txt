Hi!

These are two examples of how to use the Simple API and oEmbed to quickly
get the embed code for a Vimeo Video. These examples will embed the latest
video from a user.

For the PHP example, all you need to do is move index.php to your server.
You can try it out with a different video by appending ?url= and the the
video's url to the page.

The Javascript example should work in all browsers. You can change which
video is used by editing the "clipUrl" variable.

For more documentation on the API go to http://www.vimeo.com/api

- Brad Dougherty (October 1, 2008)